package exercises.part3;

import java.util.Arrays;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
// HINWEIS AUFGABENSTELLUNG: Verkürze second bei jedem weiteren Vergleich 
public class Exercise03_Arrays 
{
	public static void main(final String[] args) 
	{		
		final byte[] string1 = "ABC-DEF-GHI".getBytes();
		final byte[]  string2 = "DEF".getBytes();
		System.out.println(Arrays.compare(string1, string2));
		System.out.println(Arrays.compare(string1, 4, 7, 
		                                  string2, 0, 3));
		System.out.println(Arrays.compare(string1, 8, 11, 
                                          string2, 0, 3));
		
		
		final byte[] first =  "ABCDEFGHIJK".getBytes();
		final byte[] second = "XYZABCDEXYZ".getBytes();
		
		// TODO
	}
}
