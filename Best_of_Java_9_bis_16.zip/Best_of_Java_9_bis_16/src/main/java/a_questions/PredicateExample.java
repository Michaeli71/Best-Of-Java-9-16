package a_questions;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
import static java.util.function.Predicate.not;

import java.util.function.Predicate;
import java.util.stream.Stream;

public class PredicateExample {

	public static void main(String[] args) {
				
		final Predicate<String> isEmpty = String::isEmpty;
		final Predicate<String> notEmptyJdk10 = isEmpty.negate();

		Stream.of("Tim", "", "Tom", "", "Mick", "", "", "ENDE").
		       filter(not(String::isEmpty)).
		       forEach(System.out::println);
		
	}
}
