package solutions.part4_5_6;

import static java.util.stream.Collectors.counting;
import static java.util.stream.Collectors.filtering;
import static java.util.stream.Collectors.mapping;
import static java.util.stream.Collectors.teeing;

import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018/2019 by Michael Inden 
 */
public class Exercise7_Teeing 
{
	public static void main(final String[] args) 
	{
		Stream<City> exampleCities = Stream.of(
				new City("Zürich", "Europe"),
				new City("Bremen", "Europe"),
				new City("Kiel", "Europe"),
				new City("San Francisco", "America"),
				new City("Aachen", "Europe"),
				new City("Hong Kong", "Asia"),
				new City("Tokyo", "Asia"));
		
		Predicate<City> isInEurope = city -> city.locatedIn("Europe");
		Predicate<City> isInAsia = city -> city.locatedIn("Asia");
		
		var result = exampleCities.collect(teeing(									
									filtering(isInEurope, mapping(City::getName, 
											                      Collectors.toList())),
						            
									filtering(isInAsia, counting()),
						            (europeanCities, asianCityCount) -> 
									"cities in europe = " + europeanCities + 
									"/ asian city count=" + asianCityCount));

		System.out.println(result);
	}
	
	static class City 
	{
		private final String name;
		private final String region;

		public City(String name, String region) {

			this.name = name;
			this.region = region;
		}

		public String getName() {
			return name;
		}

		public String getRegion() {
			return region;
		}
		
		public boolean locatedIn(String region) {
			return this.region.equalsIgnoreCase(region);
		}
	}
}
