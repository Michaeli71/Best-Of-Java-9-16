#!/bin/bash          
echo "Starting JAVA"
java Hello.java
echo "ENDING JAVA"

# chmod u+x <file>
#
#
# package does.not.matter;
#
# public class Hello
# {
#     public static void main(String... args)
#     {
#	     System.out.println("Hello");
#	     System.out.println("Hello JAX");
#	     System.out.println("Hello");
#     }
# }
