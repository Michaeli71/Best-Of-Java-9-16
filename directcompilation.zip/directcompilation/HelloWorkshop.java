package does.not.count;

import java.time.*;

public class HelloWorkshop
{
	public static void main(String... args)
	{
		System.out.println("Hello Workshop Participants");
		LocalDate today = LocalDate.now();
		System.out.println("today is the " + today);	

		System.out.println("betterCode()");	
	}
}