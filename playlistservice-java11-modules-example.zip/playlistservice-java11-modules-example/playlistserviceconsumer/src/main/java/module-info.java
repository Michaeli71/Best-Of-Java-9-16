module playlistserviceconsumer 
{
    requires playlistservice;

    uses com.javaprofi.spi.PlaylistService;
}